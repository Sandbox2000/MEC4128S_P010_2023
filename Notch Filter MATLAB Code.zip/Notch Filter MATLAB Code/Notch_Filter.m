% Define the notch filter parameters
notchFrequencies = [22.77; 48.9; 73.67; 99; 77.67; 53.6; 31.67; 24];
notchWidths = [5; 5; 5; 1; 5; 5; 5; 5];

% Get a list of all CSV files in the directory
fileList = dir('*.csv');

% Create a directory to save the figures
outputDirectory = 'output_figures';  % Change to your desired directory name
if ~exist(outputDirectory, 'dir')
    mkdir(outputDirectory);
end

% Loop through each CSV file
for i = 1:length(fileList)
    % Load the data from the CSV file using readtable
    fileName = fileList(i).name;
    tableData = readtable(fileName);
    
    % Extract the 3rd and 5th columns where the 5th column is the time
    data = tableData{:, 3};  % 3rd column
    time = tableData{:, 5};  % 5th column
    
    % Calculate the time vector starting from 0
    startTime = time(1);
    time = time - startTime;
    
    % Get the current notch frequency and width for this iteration
    notchFrequency = notchFrequencies(i);
    notchWidth = notchWidths(i);
    
    % Calculate the notch filter coefficients using designfilt
    Fs = 200; % Assuming a sampling frequency of 1000 Hz, change as needed
    wo = notchFrequency / (Fs/2);
    bw = notchWidth / (Fs/2);
    d = designfilt('bandstopiir', 'FilterOrder', 2, 'HalfPowerFrequency1', wo-bw/2, 'HalfPowerFrequency2', wo+bw/2);
    
    % Apply the notch filter to the data
    filteredData = filtfilt(d, data);
    
    % Calculate the FFT of the original data
    L = length(data);
    fftOriginal = abs(fft((data - mean(data)).*hann(length(data)))) / 1000; % Scale FFT values by 1000
    fOriginal = Fs * (0:(L/2))/L;
    fftOriginal = fftOriginal(1:L/2+1);
    
    % Calculate the FFT of the filtered data
    L = length(filteredData);
    fftFiltered = abs(fft((filteredData - mean(filteredData)).*hann(length(filteredData)))) / 1000; % Scale FFT values by 1000
    fFiltered = Fs * (0:(L/2))/L;
    fftFiltered = fftFiltered(1:L/2+1);
    
    % Calculate the average value of the original data and filtered data
    % Calculate the average value of the original data and filtered data
    averageOriginal = mean(data);
    averageFiltered = mean(filteredData);

    % Create a new figure for each file with larger spacing
    figure('Position', [100, 100, 1000, 800]);

    % Display the original FFT
    subplot(2, 2, 2);
    plot(fOriginal, fftOriginal, 'b'); % Use dark blue color
    title(['Original FFT - ' fileName(10:length(fileName)-4)]);
    xlabel('Frequency (Hz)');
    ylabel('Magnetic Field Amplitude (mG)');
    ylim([0, 10]); % Set common y-axis limit and scale by 1000
    grid on;

    % Display the waveform with time starting from 0 and limited x-axis
    subplot(2, 2, 1);
    plot(time, data, 'r'); % Use red color
    hold on; % Hold the plot for adding the average value
    plot([0, max(time)], [averageOriginal, averageOriginal], 'b--'); % Add average as a dotted line
    text(0.65*max(time), 960, sprintf('Average: %.2f', averageOriginal), 'FontSize', 12); % Display average as text
    hold off; % Release the hold
    title(['Original Waveform - ' fileName(10:length(fileName)-4)]);
    xlabel('Time (ms)');
    ylabel('Magnetic Field Amplitude (mG)');
    xlim([0, 20480]); % Limit x-axis to 2048 seconds
    ylim([950,1250])
    grid on;

    % Display the filtered FFT
    subplot(2, 2, 4);
    plot(fFiltered, fftFiltered, 'b'); % Use dark blue color
    title(['Filtered FFT - ' fileName(10:length(fileName)-4)]);
    xlabel('Frequency (Hz)');
    ylabel('Magnetic Field Amplitude (mG)');
    ylim([0, 10]); % Set common y-axis limit and scale by 1000
    grid on;

    % Display the waveform after the notch filter
    subplot(2, 2, 3);
    plot(time, filteredData, 'r'); % Use red color
    hold on; % Hold the plot for adding the average value
    plot([0, max(time)], [averageFiltered, averageFiltered], 'b--'); % Add average as a dotted line
    text(0.65*max(time), 960, sprintf('Average: %.2f', averageFiltered), 'FontSize', 12); % Display average as text
    hold off; % Release the hold
    title(['Filtered Waveform - ' fileName(10:length(fileName)-4)]);
    xlabel('Time (ms)');
    ylabel('Magnetic Field Amplitude (mG)');
    xlim([0, 20480]); % Limit x-axis to 2048 seconds
    ylim([950,1250])
    grid on;

    % Save the figure to the output directory
    figName = fullfile(outputDirectory, [fileName(10:length(fileName)-4), '.png']);
    saveas(gcf, figName);

    % Close the current figure
    close(gcf);

end
