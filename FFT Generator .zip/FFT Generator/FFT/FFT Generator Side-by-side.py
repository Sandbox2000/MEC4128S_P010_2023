import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import glob
import scipy

# Set the y-axis limit and the line color for the average
y_axis_limit = 5
average_line_color = 'g'

path = "data/Speed Tests/Speed tests 5cm/*.csv"; iStart = 42
#path = "data/Tests 1/Low Speed/*.csv"; iStart = 34

def FFT(x):
    """
    A recursive implementation of 
    the 1D Cooley-Tukey FFT, the 
    input should have a length of 
    power of 2. 
    """
    N = len(x)
    
    if N == 1:
        return x
    else:
        X_even = FFT(x[::2])
        X_odd = FFT(x[1::2])
        factor = np.exp(-2j*np.pi*np.arange(N)/ N)
        
        X = np.concatenate([X_even + factor[:int(N/2)]*X_odd,
                            X_even + factor[int(N/2):]*X_odd])
        return X

# Get the list of CSV files
csv_files = sorted(glob.glob(path))

for filename in csv_files:
    sr = 200
    iEnd = len(filename) - 4

    # LOADING OF CSV FILE
    x = pd.read_csv(filename, index_col=['Time MCU'], usecols=[2, 4])  # Fetches Magnetic Data
    ts = 1.0 / sr
    N = len(x)
    t = np.arange(0, N / sr, ts)
    x = x.transpose()
    x = x.to_numpy()

    

    #Window = 1  # Normal window
    #Window = scipy.signal.windows.flattop(N); Window_Name = 'Flat Top'
    Window = np.hanning(N)
    
    # Calculate the average value of the waveform
    average_value = np.mean(x[0])

    # Create a new figure for each CSV file
    fig, axs = plt.subplots(nrows=1, ncols=2, figsize=(12, 6))
    fig.suptitle(f'{filename[iStart:iEnd]}', fontsize=16)

    axs[0].plot(t, x[0], 'r', label='WaveForm')
    axs[0].axhline(y=average_value, color=average_line_color, linestyle='--', label=f'Average: {average_value:.2f}')
    axs[0].set_ylabel('Magnetic Field Amplitude (mG)')
    axs[0].set_xlabel('Time (s)')
    axs[0].set_title('WaveForm')
    axs[0].legend()

    x = x - x.mean()

    X = FFT(x[0] * Window)

    N = len(X)
    n = np.arange(N)
    T = N / sr
    freq = n / T

    n_oneside = N // 2
    f_oneside = freq[:n_oneside]
    X_oneside = X[:n_oneside] / n_oneside

    axs[1].plot(f_oneside[1:], abs(X_oneside[1:]), 'b', label='FFT')
    axs[1].set_xlabel('Freq (Hz)')
    axs[1].set_ylabel('Magnetic Field Amplitude (mG)')
    #axs[1].set_ylim(0, y_axis_limit)
    axs[1].set_title('FFT')
    axs[1].legend()

    plt.tight_layout()
    plt.savefig(f'figures/{filename[iStart:iEnd]}.jpg')
    plt.show()
