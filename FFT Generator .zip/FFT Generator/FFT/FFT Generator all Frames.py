import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import glob
import scipy

# Set the y-axis limit and the line color for the average
y_axis_limit = 5
average_line_color = 'g'
iStart = 37

path = "data/Power no speed/*.csv"

def FFT(x):
    """
    A recursive implementation of 
    the 1D Cooley-Tukey FFT, the 
    input should have a length of 
    power of 2. 
    """
    N = len(x)
    
    if N == 1:
        return x
    else:
        X_even = FFT(x[::2])
        X_odd = FFT(x[1::2])
        factor = np.exp(-2j*np.pi*np.arange(N)/ N)
        
        X = np.concatenate([X_even + factor[:int(N/2)]*X_odd,
                            X_even + factor[int(N/2):]*X_odd])
        return X

# Get the list of CSV files
fig_waveform, axs_waveform = plt.subplots(figsize=(12, 6))
fig_fft, axs_fft = plt.subplots(figsize=(12, 6))

for filename in sorted(glob.glob(path)):
    sr = 200

    iEnd = len(filename) - 4

    # LOADING OF CSV FILE
    x = pd.read_csv(filename, index_col=['Time MCU'], usecols=[2, 4])  # Fetches Magnetic Data
    ts = 1.0 / sr
    N = len(x)
    t = np.arange(0, N / sr, ts)
    x = x.transpose()
    x = x.to_numpy()

    Window = 1  # Normal window
    Window = np.hanning(N)

    average_value = np.mean(x[0])

    axs_waveform.plot(t, x[0] , label=f'{filename[iStart:iEnd]} WaveForm')
    axs_waveform.axhline(y=average_value, color=average_line_color, linestyle='--', label=f'Average: {average_value:.2f}')

    x= x-x.mean()
    
    X = FFT(x[0] * Window)

    N = len(X)
    n = np.arange(N)
    T = N / sr
    freq = n / T

    n_oneside = N // 2
    f_oneside = freq[:n_oneside]
    X_oneside = X[:n_oneside] / n_oneside

    axs_fft.plot(f_oneside[1:], abs(X_oneside[1:]), label=f'{filename[iStart:iEnd]} FFT')

# Set labels and legends for the waveform and FFT figures
axs_waveform.set_ylabel('Magnetic Field Amplitude (mG)')
axs_waveform.set_xlabel('Time (s)')
axs_waveform.set_title('Normal Waveforms')
axs_waveform.legend()

axs_fft.set_xlabel('Freq (Hz)')
axs_fft.set_ylabel('Magnetic Field Amplitude (mG)')
axs_fft.set_title('FFT')
axs_fft.set_ylim(0, y_axis_limit)
axs_fft.legend()

plt.tight_layout()
fig_waveform.tight_layout()
fig_waveform.savefig(f'figures/{filename[iStart:iEnd]} Waveform.jpg',dpi=1200)
fig_fft.savefig(f'figures/{filename[iStart:iEnd]} FFT.jpg',dpi=1200)
plt.show()
